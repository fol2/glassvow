extends SceneTree
## Exact-runtime cross-enemy Facet identity preflight for issue #421.

const Policy: GDScript = preload("res://tools/balance_policy.gd")
const Sim: GDScript = preload("res://tools/balance_sim.gd")


func _initialize() -> void:
	var opts: Dictionary = _options(OS.get_cmdline_user_args())
	if opts.has("error"):
		_fail(str(opts["error"]))
		return
	var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string(str(opts["plan"])))
	if typeof(raw) != TYPE_DICTIONARY:
		_fail("plan must be a dictionary")
		return
	var plan: Dictionary = raw
	var content: ContentDB = ContentDB.load_from(str(plan.get("content", "")), false)
	if content == null:
		_fail("content did not load")
		return
	var mode: String = str(plan.get("mode", ""))
	var rows: Array[Dictionary] = []
	if mode == "direct":
		rows = _direct(content, plan.get("rows", []))
	elif mode == "whole-runs":
		rows = _whole_runs(content, plan.get("rows", []))
	else:
		_fail("mode must be direct or whole-runs")
		return
	var output: Dictionary = {
		"schemaVersion": 1,
		"planSha256": FileAccess.get_sha256(str(opts["plan"])),
		"probeSha256": FileAccess.get_sha256(str(get_script().resource_path)),
		"rows": rows,
	}
	var file: FileAccess = FileAccess.open(str(opts["out"]), FileAccess.WRITE)
	if file == null:
		_fail("cannot write output")
		return
	file.store_string(JSON.stringify(output) + "\n")
	print(JSON.stringify({"status": "PASS", "rows": rows.size()}))
	quit(0)


func _direct(content: ContentDB, raw_rows: Variant) -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	if typeof(raw_rows) != TYPE_ARRAY:
		_fail("direct rows must be an array")
		return rows
	for spec_v: Variant in raw_rows:
		if typeof(spec_v) != TYPE_DICTIONARY:
			_fail("every direct row must be a dictionary")
			return []
		var spec: Dictionary = spec_v
		rows.append(_direct_control(content, spec))
	return rows


func _direct_control(content: ContentDB, spec: Dictionary) -> Dictionary:
	var states_v: Variant = spec.get("enemies", [])
	if typeof(states_v) != TYPE_ARRAY or states_v.is_empty():
		_fail("direct enemies must be a non-empty array")
		return {}
	var aspect: int = 1 if str(spec["aspect"]) == "ashwarden" else 0
	var run: RunState = RunState.new_run(
		content, _int(spec, "seed"), "cross-facet-%s" % str(spec["id"]), {"aspect": aspect})
	var game: GlassvowGame = GlassvowGame.new(content, run)
	var enemy_ids: Array[String] = []
	for _state_v: Variant in states_v:
		enemy_ids.append("rootheart")
	game.apply({"t": "startCombat", "enemies": enemy_ids, "kind": "normal"})
	game.cb.queue.clear()
	game.cb.player.energy = 3
	game.cb.player.statuses.clear()
	game.rules.research_cross_enemy_facet = _bool(spec, "factor")
	var enemy_before: Array[Dictionary] = []
	for i: int in range(states_v.size()):
		var state: Dictionary = states_v[i]
		var enemy: EnemyCombatant = game.cb.enemies[i]
		enemy.max_hp = 100
		enemy.hp = _int(state, "hp")
		enemy.block = _int(state, "block")
		enemy.chips = _int(state, "chips")
		enemy.facet_max = _int(state, "facetMax")
		enemy.statuses.clear()
		enemy_before.append(_enemy_row(enemy))
	var card_id: StringName = StringName(str(spec["card"]))
	var card: CardInst = CardInst.new(game.run.next_uid(), card_id, false)
	game.cb.hand.append(card)
	var target_v: Variant = spec.get("target")
	var target: Variant = null if target_v == null else _int(spec, "target")
	var rng_before: int = game.run.rng_state()
	var events: Array[Dictionary] = game.apply(
		{"t": "playCard", "uid": card.uid, "target": target})
	var enemy_after: Array[Dictionary] = []
	for enemy: EnemyCombatant in game.cb.enemies:
		enemy_after.append(_enemy_row(enemy))
	var chip_events: Array[Dictionary] = []
	for event_v: Variant in events:
		var event: Dictionary = event_v
		if str(event.get("t", "")) == "chip":
			chip_events.append({"idx": _int(event, "idx"), "n": _int(event, "n"),
				"chips": _int(event, "chips"), "facetMax": _int(event, "facetMax")})
	return {
		"id": str(spec["id"]),
		"aspect": str(spec["aspect"]),
		"factor": _bool(spec, "factor"),
		"card": str(card_id),
		"target": target,
		"playReturned": game.last_ret,
		"enemyBefore": enemy_before,
		"enemyAfter": enemy_after,
		"chipEvents": chip_events,
		"rngBefore": rng_before,
		"rngAfter": game.run.rng_state(),
	}


func _whole_runs(content: ContentDB, raw_rows: Variant) -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	if typeof(raw_rows) != TYPE_ARRAY:
		_fail("whole-run rows must be an array")
		return rows
	for spec_v: Variant in raw_rows:
		if typeof(spec_v) != TYPE_DICTIONARY:
			_fail("every whole-run row must be a dictionary")
			return []
		var spec: Dictionary = spec_v
		var arm: String = str(spec.get("arm", ""))
		if arm not in ["omitted", "explicit-false"]:
			_fail("whole-run arm must be omitted or explicit-false")
			return []
		var policies: Array[Dictionary] = Policy.sample_range(
			_int(spec, "policyRoot"), _int(spec, "policyIndex"), 1)
		var trace: Dictionary = {"capture": _bool(spec, "capture")}
		var factor: Variant = null if arm == "omitted" else false
		var row: Dictionary = Sim.simulate(
			content, str(spec["aspect"]), _int(spec, "seed"), _int(spec, "vow"),
			PackedStringArray(), policies[0], false, false, {}, null, false, factor, trace)
		row["id"] = str(spec["id"])
		row["arm"] = arm
		row["capture"] = _bool(spec, "capture")
		row["policyIndex"] = _int(spec, "policyIndex")
		row["trajectory"] = trace
		rows.append(row)
	return rows


static func _enemy_row(enemy: EnemyCombatant) -> Dictionary:
	return {"hp": enemy.hp, "block": enemy.block, "chips": enemy.chips,
		"facetMax": enemy.facet_max}


static func _int(values: Dictionary, key: String) -> int:
	var value: Variant = values.get(key, 0)
	return value if typeof(value) == TYPE_INT else int(float(str(value)))


static func _bool(values: Dictionary, key: String) -> bool:
	var value: Variant = values.get(key, false)
	return value if typeof(value) == TYPE_BOOL else false


func _fail(message: String) -> void:
	push_error("research_421_cross_enemy_facet_identity_probe: %s" % message)
	quit(2)


static func _options(args: PackedStringArray) -> Dictionary:
	var out: Dictionary = {"plan": "", "out": ""}
	for arg: String in args:
		if not arg.begins_with("--") or not arg.contains("="):
			return {"error": "expected --name=value"}
		var key: String = arg.get_slice("=", 0).trim_prefix("--")
		if not out.has(key):
			return {"error": "unknown option --%s" % key}
		out[key] = arg.substr(arg.find("=") + 1)
	if str(out["plan"]).is_empty() or str(out["out"]).is_empty():
		return {"error": "--plan and --out are required"}
	return out
