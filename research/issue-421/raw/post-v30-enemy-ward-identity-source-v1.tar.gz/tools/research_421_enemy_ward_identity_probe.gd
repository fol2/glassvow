extends SceneTree
## Exact-runtime enemy-Ward Facet identity preflight for issue #421.

const Policy: GDScript = preload("res://tools/balance_policy.gd")
const Sim: GDScript = preload("res://tools/balance_sim.gd")


func _initialize() -> void:
	var opts: Dictionary = _options(OS.get_cmdline_user_args())
	if opts.has("error"):
		_fail(str(opts["error"]))
		return
	var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string(str(opts["plan"])))
	if typeof(raw) != TYPE_DICTIONARY:
		_fail("plan must be a dictionary")
		return
	var plan: Dictionary = raw
	var content: ContentDB = ContentDB.load_from(str(plan.get("content", "")), false)
	if content == null:
		_fail("content did not load")
		return
	var mode: String = str(plan.get("mode", ""))
	var rows: Array[Dictionary] = []
	if mode == "direct":
		rows = _direct(content, plan.get("rows", []))
	elif mode == "whole-runs":
		rows = _whole_runs(content, plan.get("rows", []))
	else:
		_fail("mode must be direct or whole-runs")
		return
	var output: Dictionary = {
		"schemaVersion": 1,
		"planSha256": FileAccess.get_sha256(str(opts["plan"])),
		"probeSha256": FileAccess.get_sha256(str(get_script().resource_path)),
		"rows": rows,
	}
	var file: FileAccess = FileAccess.open(str(opts["out"]), FileAccess.WRITE)
	if file == null:
		_fail("cannot write output")
		return
	file.store_string(JSON.stringify(output) + "\n")
	print(JSON.stringify({"status": "PASS", "rows": rows.size()}))
	quit(0)


func _direct(content: ContentDB, raw_rows: Variant) -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	if typeof(raw_rows) != TYPE_ARRAY:
		_fail("direct rows must be an array")
		return rows
	for spec_v: Variant in raw_rows:
		if typeof(spec_v) != TYPE_DICTIONARY:
			_fail("every direct row must be a dictionary")
			return []
		var spec: Dictionary = spec_v
		rows.append(_direct_control(content, spec))
	return rows


func _direct_control(content: ContentDB, spec: Dictionary) -> Dictionary:
	var aspect: int = 1 if str(spec["aspect"]) == "ashwarden" else 0
	var run: RunState = RunState.new_run(
		content, _int(spec, "seed"), "enemy-ward-%s" % str(spec["id"]), {"aspect": aspect})
	var game: GlassvowGame = GlassvowGame.new(content, run)
	game.apply({"t": "startCombat", "enemies": ["rootheart"], "kind": "normal"})
	game.cb.queue.clear()
	game.cb.player.energy = 3
	game.cb.player.statuses.clear()
	if _int(spec, "beacon") > 0:
		game.cb.player.statuses["beacon"] = _int(spec, "beacon")
	game.rules.research_enemy_ward_facet = _bool(spec, "factor")
	game.rules.research_enemy_ward_trace = true
	var enemy: EnemyCombatant = game.cb.enemies[0]
	enemy.max_hp = 100
	enemy.hp = _int(spec, "hp")
	enemy.block = _int(spec, "block")
	enemy.chips = _int(spec, "chips")
	enemy.facet_max = _int(spec, "facetMax")
	enemy.statuses.clear()
	var card: CardInst = CardInst.new(
		game.run.next_uid(), StringName(str(spec["card"])), _bool(spec, "upgraded"))
	game.cb.hand.append(card)
	var preview_v: Variant = game.rules.preview_play(game.cb, card, 0, game.run)
	var preview: Dictionary = preview_v if typeof(preview_v) == TYPE_DICTIONARY else {}
	var enemy_before: Dictionary = _enemy_row(enemy)
	var rng_before: int = game.run.rng_state()
	var events: Array[Dictionary] = game.apply({"t": "playCard", "uid": card.uid, "target": 0})
	var hit_events: Array[Dictionary] = []
	var chip_events: Array[Dictionary] = []
	var event_kinds: Array[String] = []
	for event_v: Variant in events:
		var event: Dictionary = event_v
		var kind: String = str(event.get("t", ""))
		event_kinds.append(kind)
		if kind == "hitEnemy":
			hit_events.append({
				"idx": _int(event, "idx"),
				"amount": _int(event, "amount"),
				"blocked": _int(event, "blocked"),
				"hpAfter": _int(event, "hpAfter"),
				"blockBefore": _int(event, "blockBefore"),
				"blockAfter": _int(event, "blockAfter"),
				"pendingChipsActive": _bool(event, "pendingChipsActive"),
				"isAttack": _bool(event, "isAttack"),
				"duskAspect": _bool(event, "duskAspect"),
				"wardBreakWithoutBlood": _bool(event, "wardBreakWithoutBlood"),
				"facetHitFlagged": _bool(event, "facetHitFlagged"),
				"researchFacetHitFlagged": _bool(event, "researchFacetHitFlagged"),
			})
		elif kind == "chip":
			chip_events.append({
				"idx": _int(event, "idx"), "n": _int(event, "n"),
				"chips": _int(event, "chips"), "facetMax": _int(event, "facetMax"),
			})
	return {
		"id": str(spec["id"]),
		"aspect": str(spec["aspect"]),
		"factor": _bool(spec, "factor"),
		"card": str(card.id),
		"upgraded": card.up,
		"target": 0,
		"beacon": _int(spec, "beacon"),
		"playReturned": game.last_ret,
		"preview": {
			"hits": preview.get("hits", []),
			"total": _int(preview, "total"),
			"loss": _int(preview, "loss"),
			"lethal": _bool(preview, "lethal"),
			"chips": _int(preview, "chips"),
			"willShatter": _bool(preview, "willShatter"),
		},
		"enemyBefore": enemy_before,
		"enemyAfter": _enemy_row(enemy),
		"hitEvents": hit_events,
		"chipEvents": chip_events,
		"eventKinds": event_kinds,
		"playerAfter": {
			"hp": game.cb.player.hp,
			"energy": game.cb.player.energy,
			"beacon": _int(game.cb.player.statuses, "beacon"),
		},
		"rngBefore": rng_before,
		"rngAfter": game.run.rng_state(),
	}


func _whole_runs(content: ContentDB, raw_rows: Variant) -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	if typeof(raw_rows) != TYPE_ARRAY:
		_fail("whole-run rows must be an array")
		return rows
	for spec_v: Variant in raw_rows:
		if typeof(spec_v) != TYPE_DICTIONARY:
			_fail("every whole-run row must be a dictionary")
			return []
		var spec: Dictionary = spec_v
		var arm: String = str(spec.get("arm", ""))
		if arm not in ["omitted", "explicit-false"]:
			_fail("whole-run arm must be omitted or explicit-false")
			return []
		var policies: Array[Dictionary] = Policy.sample_range(
			_int(spec, "policyRoot"), _int(spec, "policyIndex"), 1)
		var trace: Dictionary = {"capture": _bool(spec, "capture")}
		var factor: Variant = null if arm == "omitted" else false
		var row: Dictionary = Sim.simulate(
			content, str(spec["aspect"]), _int(spec, "seed"), _int(spec, "vow"),
			PackedStringArray(), policies[0], false, false, {}, null, false, factor, trace)
		row["id"] = str(spec["id"])
		row["arm"] = arm
		row["capture"] = _bool(spec, "capture")
		row["policyIndex"] = _int(spec, "policyIndex")
		row["trajectory"] = trace
		rows.append(row)
	return rows


static func _enemy_row(enemy: EnemyCombatant) -> Dictionary:
	return {"hp": enemy.hp, "block": enemy.block, "chips": enemy.chips,
		"facetMax": enemy.facet_max}


static func _int(values: Dictionary, key: String) -> int:
	var value: Variant = values.get(key, 0)
	return value if typeof(value) == TYPE_INT else int(float(str(value)))


static func _bool(values: Dictionary, key: String) -> bool:
	var value: Variant = values.get(key, false)
	return value if typeof(value) == TYPE_BOOL else false


func _fail(message: String) -> void:
	push_error("research_421_enemy_ward_identity_probe: %s" % message)
	quit(2)


static func _options(args: PackedStringArray) -> Dictionary:
	var out: Dictionary = {"plan": "", "out": ""}
	for arg: String in args:
		if not arg.begins_with("--") or not arg.contains("="):
			return {"error": "expected --name=value"}
		var key: String = arg.get_slice("=", 0).trim_prefix("--")
		if not out.has(key):
			return {"error": "unknown option --%s" % key}
		out[key] = arg.substr(arg.find("=") + 1)
	if str(out["plan"]).is_empty() or str(out["out"]).is_empty():
		return {"error": "--plan and --out are required"}
	return out
