extends SceneTree
## Exact-runtime Lantern-Art identity preflight for issue #421.

const Policy: GDScript = preload("res://tools/balance_policy.gd")
const Sim: GDScript = preload("res://tools/balance_sim.gd")


func _initialize() -> void:
	var opts: Dictionary = _options(OS.get_cmdline_user_args())
	if opts.has("error"):
		_fail(str(opts["error"]))
		return
	var raw: Variant = JSON.parse_string(FileAccess.get_file_as_string(str(opts["plan"])))
	if typeof(raw) != TYPE_DICTIONARY:
		_fail("plan must be a dictionary")
		return
	var plan: Dictionary = raw
	var content: ContentDB = ContentDB.load_from(str(plan.get("content", "")), false)
	if content == null:
		_fail("content did not load")
		return
	var mode: String = str(plan.get("mode", ""))
	var rows: Array[Dictionary] = []
	if mode == "direct":
		rows = _direct(content, plan.get("rows", []))
	elif mode == "whole-runs":
		rows = _whole_runs(content, plan.get("rows", []))
	else:
		_fail("mode must be direct or whole-runs")
		return
	var output: Dictionary = {
		"schemaVersion": 1,
		"planSha256": FileAccess.get_sha256(str(opts["plan"])),
		"probeSha256": FileAccess.get_sha256(str(get_script().resource_path)),
		"rows": rows,
	}
	var file: FileAccess = FileAccess.open(str(opts["out"]), FileAccess.WRITE)
	if file == null:
		_fail("cannot write output")
		return
	file.store_string(JSON.stringify(output) + "\n")
	print(JSON.stringify({"status": "PASS", "rows": rows.size()}))
	quit(0)


func _direct(content: ContentDB, raw_rows: Variant) -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	if typeof(raw_rows) != TYPE_ARRAY:
		_fail("direct rows must be an array")
		return rows
	for spec_v: Variant in raw_rows:
		if typeof(spec_v) != TYPE_DICTIONARY:
			_fail("every direct row must be a dictionary")
			return []
		var spec: Dictionary = spec_v
		var kind: String = str(spec.get("kind", ""))
		if kind == "art":
			rows.append(_art_control(content, spec))
		elif kind == "attack":
			rows.append(_attack_control(content, spec))
		else:
			_fail("direct kind must be art or attack")
			return []
	return rows


func _game(content: ContentDB, spec: Dictionary, enemy_count: int) -> GlassvowGame:
	var aspect: int = 1 if str(spec["aspect"]) == "ashwarden" else 0
	var run: RunState = RunState.new_run(
		content, _int(spec, "seed"), "art-identity-%s" % str(spec["id"]), {"aspect": aspect})
	var art: String = str(spec.get("art", ""))
	if not art.is_empty():
		run.art = StringName(art)
	var game: GlassvowGame = GlassvowGame.new(content, run)
	var enemies: Array[String] = []
	for _i: int in range(enemy_count):
		enemies.append("rootheart")
	game.apply({"t": "startCombat", "enemies": enemies, "kind": "normal"})
	game.cb.queue.clear()
	game.cb.embers = 4
	game.cb.player.energy = 3
	game.cb.player.statuses.clear()
	for enemy: EnemyCombatant in game.cb.enemies:
		enemy.hp = enemy.max_hp
		enemy.block = _int(spec, "block")
		enemy.chips = 0
		enemy.facet_max = 8
		enemy.statuses.clear()
	return game


func _art_control(content: ContentDB, spec: Dictionary) -> Dictionary:
	var game: GlassvowGame = _game(content, spec, 2)
	var hp_before: Array[int] = []
	for enemy: EnemyCombatant in game.cb.enemies:
		hp_before.append(enemy.hp)
	var rng_before: int = game.run.rng_state()
	var events: Array[Dictionary] = game.apply({"t": "useArt"})
	var hp_after: Array[int] = []
	for enemy: EnemyCombatant in game.cb.enemies:
		hp_after.append(enemy.hp)
	return {
		"id": str(spec["id"]), "kind": "art", "aspect": str(spec["aspect"]),
		"art": str(game.run.art), "canUse": game.rules.can_use_art(game.run, game.cb),
		"embersBefore": 4, "embersAfter": game.cb.embers,
		"hpBefore": hp_before, "hpAfter": hp_after,
		"playerStatuses": game.cb.player.statuses.duplicate(), "events": events,
		"rngBefore": rng_before, "rngAfter": game.run.rng_state(),
	}


func _attack_control(content: ContentDB, spec: Dictionary) -> Dictionary:
	var game: GlassvowGame = _game(content, spec, 1)
	var art_events: Array[Dictionary] = []
	if _bool(spec, "useArt"):
		art_events = game.apply({"t": "useArt"})
	var enemy: EnemyCombatant = game.cb.enemies[0]
	var strike: CardInst = CardInst.new(game.run.next_uid(), &"strike", false)
	game.cb.hand.append(strike)
	var hp_before: int = enemy.hp
	var block_before: int = enemy.block
	var rng_before: int = game.run.rng_state()
	var attack_events: Array[Dictionary] = game.apply(
		{"t": "playCard", "uid": strike.uid, "target": 0})
	return {
		"id": str(spec["id"]), "kind": "attack", "aspect": str(spec["aspect"]),
		"art": str(spec.get("art", "")), "artUsed": _bool(spec, "useArt"),
		"blockBefore": block_before, "blockAfter": enemy.block,
		"hpBefore": hp_before, "hpAfter": enemy.hp,
		"chips": enemy.chips, "facetMax": enemy.facet_max,
		"embers": game.cb.embers, "playerStatuses": game.cb.player.statuses.duplicate(),
		"playReturned": game.last_ret, "artEvents": art_events,
		"attackEvents": attack_events, "rngBefore": rng_before,
		"rngAfter": game.run.rng_state(),
	}


func _whole_runs(content: ContentDB, raw_rows: Variant) -> Array[Dictionary]:
	var rows: Array[Dictionary] = []
	if typeof(raw_rows) != TYPE_ARRAY:
		_fail("whole-run rows must be an array")
		return rows
	for spec_v: Variant in raw_rows:
		if typeof(spec_v) != TYPE_DICTIONARY:
			_fail("every whole-run row must be a dictionary")
			return []
		var spec: Dictionary = spec_v
		var arm: String = str(spec.get("arm", ""))
		if arm not in ["omitted", "explicit-flare", "beacon"]:
			_fail("whole-run arm must be omitted, explicit-flare or beacon")
			return []
		var policies: Array[Dictionary] = Policy.sample_range(
			_int(spec, "policyRoot"), _int(spec, "policyIndex"), 1)
		var trace: Dictionary = {"capture": true}
		var art: StringName = &"beacon" if arm == "beacon" \
			else (&"flare" if arm == "explicit-flare" else &"")
		var row: Dictionary = Sim.simulate(
			content, str(spec["aspect"]), _int(spec, "seed"), _int(spec, "vow"),
			PackedStringArray(), policies[0], false, false, {}, null, false, art, trace)
		row["id"] = str(spec["id"])
		row["arm"] = arm
		row["policyIndex"] = _int(spec, "policyIndex")
		row["trajectory"] = trace
		rows.append(row)
	return rows


static func _int(values: Dictionary, key: String) -> int:
	var value: Variant = values.get(key, 0)
	return value if typeof(value) == TYPE_INT else int(float(str(value)))


static func _bool(values: Dictionary, key: String) -> bool:
	var value: Variant = values.get(key, false)
	return value if typeof(value) == TYPE_BOOL else false


func _fail(message: String) -> void:
	push_error("research_421_lantern_art_identity_probe: %s" % message)
	quit(2)


static func _options(args: PackedStringArray) -> Dictionary:
	var out: Dictionary = {"plan": "", "out": ""}
	for arg: String in args:
		if not arg.begins_with("--") or not arg.contains("="):
			return {"error": "expected --name=value"}
		var key: String = arg.get_slice("=", 0).trim_prefix("--")
		if not out.has(key):
			return {"error": "unknown option --%s" % key}
		out[key] = arg.substr(arg.find("=") + 1)
	if str(out["plan"]).is_empty() or str(out["out"]).is_empty():
		return {"error": "--plan and --out are required"}
	return out
