import copy
import unittest
import control_feasibility as c

class BoundTests(unittest.TestCase):
    def test_recorded_dusk(self):
        r=c.bound(44,64)
        self.assertEqual(r['upper_bound_fraction'],'5/16')
        self.assertFalse(r['observed_35pp_gap_possible_by_policy_only'])
    def test_recorded_ash(self):
        r=c.bound(46,64)
        self.assertEqual(r['upper_bound_fraction'],'9/32')
        self.assertFalse(r['observed_35pp_gap_possible_by_policy_only'])
    def test_exact_threshold(self):
        self.assertTrue(c.bound(65,100)['observed_35pp_gap_possible_by_policy_only'])
        self.assertFalse(c.bound(66,100)['observed_35pp_gap_possible_by_policy_only'])
    def test_extremes(self):
        self.assertEqual(c.bound(0,64)['perfect_strategy_gap_upper_bound'],1)
        self.assertEqual(c.bound(64,64)['perfect_strategy_gap_upper_bound'],0)
    def test_no_false_C2_verdict(self):
        for w in (0,17,44,46,64):
            self.assertEqual(c.bound(w,64)['signed_C2_verdict'],'NOT_EVALUATED')
    def test_invalid_counts(self):
        for w in (-1,65,True,44.0,'44'):
            with self.assertRaises(ValueError):c.bound(w,64)
    def test_invalid_denominator(self):
        for n in (0,-1,True,64.0):
            with self.assertRaises(ValueError):c.bound(0,n)

class BindingTests(unittest.TestCase):
    def setUp(self):
        self.data={'status':'COMPLETE_PUBLISHED_FIXED_VALIDATION_NOT_P9','content_sha256':c.CANDIDATE,
         'descriptor_sha256':c.MODEL,'rows':1024,'full_raw_included':False,
         'counts':{'win':721,'loss':303,'stall':0,'error':0},'cells':[]}
        self.pr={'controls':'same balanced research controller; not the signed original arm2',
         'model_sha256':c.MODEL,'content_sha256':c.CANDIDATE,'assigned_runs':1024,'runs_per_context':64}
        nums=iter([52,60,58,44,27,36,36,17,57,56,61,46,57,44,48,22])
        for a in (0,1):
            for v in (0,5):
                for r in (*c.ROUTES[a],'balanced'):
                    self.data['cells'].append({'aspect':a,'vow':v,'route':r,'wins':next(nums),'n':64})
    def test_complete(self):
        result=c.analyze(self.data,self.pr)
        self.assertEqual(len(result['controls']),4)
        self.assertFalse(result['p9_certified'])
    def test_duplicate_rejected(self):
        self.data['cells'][-1]=copy.deepcopy(self.data['cells'][0])
        with self.assertRaises(ValueError):c.analyze(self.data,self.pr)
    def test_missing_rejected(self):
        self.data['cells'].pop()
        with self.assertRaises(ValueError):c.analyze(self.data,self.pr)
    def test_refit_rejected(self):
        self.data['descriptor_sha256']='other'
        with self.assertRaises(ValueError):c.analyze(self.data,self.pr)
    def test_control_relabel_rejected(self):
        self.pr['controls']='signed original arm2'
        with self.assertRaises(ValueError):c.analyze(self.data,self.pr)
    def test_raw_promotion_rejected(self):
        self.data['full_raw_included']=True
        with self.assertRaises(ValueError):c.analyze(self.data,self.pr)
    def test_changed_horizon_rejected(self):
        self.pr['runs_per_context']=128
        with self.assertRaises(ValueError):c.analyze(self.data,self.pr)

if __name__=='__main__':unittest.main()
