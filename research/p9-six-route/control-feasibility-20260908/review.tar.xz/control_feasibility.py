"""Post-observation arithmetic and source binding; never a signed C2 verdict.

Usage: python control_feasibility.py REPO
Only reads the completed 1,024-row compact validation and its original contract.
No game, model, cohort or frozen result is changed.
"""
from fractions import Fraction
import hashlib
import json
from pathlib import Path
import sys

ROOT = 'research/p9-six-route/natural-contribution-20260907/replication/'
BINDINGS = {
    ROOT+'continuation-20260908/PUBLISHED-VALIDATION.json': '8a96ea161f8e4324b6c65e882d2b6cee8239061e368ed743d94397df02a7fa83',
    ROOT+'PREREGISTRATION.json': 'a726f42801f317cf8c6bf0fdd4610cd555d0d2055a3efcee6be497a38ebe558f',
    'docs/balance/2026-08-14-strategy-landscape.md': 'c3a47d38d98d00a9c53942b86b024e432d451ecf28a073cc26d9bff844d0e1ca',
}
CANDIDATE = '3c7b2f9dba362d19128ef82ad559d3f26e54925371d823a665767032255eadaa'
MODEL = '2cfe1d8ff00d5ff695664c597be3a93e3960f39732fa049eac82b9397184bab7'
ROUTES = (('facet','fervor','cycle'),('smolder','hand','cycle'))

def require(ok, reason):
    if not ok:
        raise ValueError(reason)

def bound(wins, n):
    require(type(n) is int and n > 0, 'denominator')
    require(type(wins) is int and 0 <= wins <= n, 'wins')
    upper = Fraction(n-wins, n)
    return {'random_build_wins': wins, 'n': n, 'random_build_rate': float(Fraction(wins,n)),
        'perfect_strategy_gap_upper_bound': float(upper),
        'upper_bound_fraction': str(upper),
        'observed_35pp_gap_possible_by_policy_only': upper >= Fraction(35,100),
        'signed_C2_verdict': 'NOT_EVALUATED'}

def analyze(data, prereg):
    require(data['status']=='COMPLETE_PUBLISHED_FIXED_VALIDATION_NOT_P9', 'status')
    require(data['content_sha256']==CANDIDATE and data['descriptor_sha256']==MODEL, 'candidate/model')
    require(data['rows']==1024 and data['full_raw_included'] is False, 'coverage')
    require(data['counts']=={'win':721,'loss':303,'stall':0,'error':0}, 'outcomes')
    require(prereg['controls']=='same balanced research controller; not the signed original arm2', 'control relabel')
    require(prereg['model_sha256']==MODEL and prereg['content_sha256']==CANDIDATE, 'prereg binding')
    require(prereg['assigned_runs']==1024 and prereg['runs_per_context']==64, 'frozen horizon')
    expected={(a,v,r) for a in (0,1) for v in (0,5) for r in (*ROUTES[a],'balanced')}
    cells={}
    for row in data['cells']:
        key=(row['aspect'],row['vow'],row['route'])
        require(key in expected and key not in cells and row['n']==64, 'cell coverage')
        bound(row['wins'],row['n'])
        cells[key]=row
    require(set(cells)==expected and sum(r['wins'] for r in cells.values())==721, 'complete assignment')
    result=[]
    for a in (0,1):
        for v in (0,5):
            control=cells[a,v,'balanced']
            best=max(cells[a,v,r]['wins'] for r in ROUTES[a])
            result.append({'aspect':('duskblade','ashwarden')[a], 'vow':v,
                **bound(control['wins'],control['n']), 'best_recorded_route_wins':best,
                'best_observed_gap':float(Fraction(best-control['wins'],64))})
    return {'status':'EXACT_EXPOSED_CONTROL_FEASIBILITY_BOUND_NOT_C2_ADMISSION',
        'review_kind':'AUTHOR_SELF_REVIEW_NOT_INDEPENDENT', 'candidate_sha256':CANDIDATE,
        'controls':result,
        'decision':'On the two recorded V0 research control assignments, policy-only improvement cannot create a 35 percentage-point gap. Address this common limitation before committing to expensive candidate-wide certification; do not lower the control quality or reclassify the old experiment.',
        'scope':'Finite arithmetic bound on recorded outcomes, not a population bound or a new acceptance rule. The research control is explicitly not the signed original arm2. No actual signed C2 PASS/FAIL is issued.',
        'source_eligibility':'Source-bound hand-size work can proceed independently; this result does not invalidate the permitted inherited hand family or prove that a new content candidate is necessary.',
        'roadmap_dependency':'Before a large new support/confirmation batch, freeze how competent planned and random-build controls are validated and how the retained stronger-control counterevidence will be handled. Reuse the completed controls, do not retune them to pass.',
        'prohibited_inferences':['No population impossibility','No signed C2 failure','No authority to rerun/refit the frozen panel','No universal package nonviability'],
        'new_native_runs':0, 'new_independent_samples':0, 'model_refit':False, 'p9_certified':False}

def main(repo):
    repo=Path(repo); raw={}
    for name,expected in BINDINGS.items():
        b=(repo/name).read_bytes()
        require(hashlib.sha256(b).hexdigest()==expected, 'source identity:'+name)
        raw[name]=b
    result=analyze(json.loads(raw[ROOT+'continuation-20260908/PUBLISHED-VALIDATION.json']),
                   json.loads(raw[ROOT+'PREREGISTRATION.json']))
    result['input_files']={p:{'sha256':BINDINGS[p],'bytes':len(b)} for p,b in raw.items()}
    return result

if __name__=='__main__':
    if len(sys.argv)!=2:
        raise SystemExit(__doc__)
    print(json.dumps(main(sys.argv[1]),indent=2))
