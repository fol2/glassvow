extends RefCounted
static var totals: Dictionary = {}
static func record(name: String, elapsed: int) -> void:
 if not totals.has(name):totals[name]={"calls":0,"usec":0}
 totals[name]["calls"]+=1
 totals[name]["usec"]+=elapsed
static func result() -> Dictionary:
 return totals.duplicate(true)
