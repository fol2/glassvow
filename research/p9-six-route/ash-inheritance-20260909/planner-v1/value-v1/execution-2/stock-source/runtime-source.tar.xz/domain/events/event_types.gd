class_name EventTypes
extends RefCounted
## GameEvent "t" values (SKILL §2/§7). Names mirror the web engine's event
## strings exactly — they are the parity contract with the recorded fixtures.

const INTENT: StringName = &"intent"
const TURN: StringName = &"turn"
const ENERGY: StringName = &"energy"
const DRAW: StringName = &"draw"
const RESHUFFLE: StringName = &"reshuffle"
const PLAY: StringName = &"play"
const BLOCK_GAIN: StringName = &"blockGain"
const HIT_ENEMY: StringName = &"hitEnemy"
const HIT_PLAYER: StringName = &"hitPlayer"
const CHIP: StringName = &"chip"
const SHATTER: StringName = &"shatter"
const STAGGERED: StringName = &"staggered"
const DIE: StringName = &"die"
const EMBER: StringName = &"ember"
const STATUS: StringName = &"status"
const TO_DISCARD: StringName = &"toDiscard"
const EXHAUST: StringName = &"exhaust"
const KINDLE: StringName = &"kindle"
const ART: StringName = &"art"
const POTION: StringName = &"potion"
const DISCARD_HAND: StringName = &"discardHand"
const END_TURN: StringName = &"endTurn"
const ENEMY_ACT: StringName = &"enemyAct"
const SMOLDER_JUMP: StringName = &"smolderJump"
const HEAL: StringName = &"heal"
const POWER_CONSUMED: StringName = &"powerConsumed"
const RELIC_PROC: StringName = &"relicProc"
const VICTORY: StringName = &"victory"
const DEFEAT: StringName = &"defeat"
## The boss announces itself at startCombat (engine.js:1133).
const BOSS_INTRO: StringName = &"bossIntro"
## A variant speaks — its authored lines at startCombat, its death line on
## the killing blow (engine.js:1135-1139, :1384-1385).
const VARIANT_DIALOGUE: StringName = &"variantDialogue"
## Act IV Keeper: a lethal blow does not kill. Combat ends; #312 takes the scene.
const FINALE_HANDOFF: StringName = &"finaleHandoff"
