class_name LineTable
extends RefCounted
## One flat narrative table. Reveal-ladder enforcement is the `conditions`
## column — there is no parallel gate. Phase-1 signed vocabulary is textual:
## `shards>=N` / `act=N` / `quest:<id>.<state>` / `quest:<id>>=N`. The loader
## normalizes those clauses to an internal dict; unknown keys and unknown
## quest states fail the table load.

const L1_SHARDS: int = 1
const L2_SHARDS: int = 4
const L3_SHARDS: int = 6
const DEFAULT_COOLDOWN_RUNS: int = 3
const RECENT_CAP: int = 8
const QUEST_STATES: Array[String] = ["dormant", "armed", "revealed", "complete"]
const _SHARDS_CLAUSE: String = "^shards>=(\\d+)$"
const _ACT_CLAUSE: String = "^act=(\\d+)$"
const _QUEST_CLAUSE: String = "^quest:([A-Za-z][A-Za-z0-9]*)\\.([A-Za-z][A-Za-z0-9]*)$"
const _QUEST_PROGRESS_CLAUSE: String = "^quest:([A-Za-z][A-Za-z0-9]*)>=(\\d+)$"


static func _ji(value: Variant) -> int:
	return int(float(str(value)))


## `{ok: bool, conditions: Dictionary, error: String}`. Empty input is the
## generic fallback. A non-empty dict is rejected — that is the internal form,
## not the signed vocabulary.
static func parse_conditions(value: Variant) -> Dictionary:
	if typeof(value) == TYPE_NIL:
		return _parsed({}, "")
	if typeof(value) == TYPE_DICTIONARY:
		var as_dict: Dictionary = value
		if as_dict.is_empty():
			return _parsed({}, "")
		return _parsed({}, "conditions must be textual (shards>=N / act=N / quest:<id>.<state> / quest:<id>>=N)")
	if typeof(value) == TYPE_STRING:
		return _parse_clause_list(_split_clauses(str(value)))
	if typeof(value) != TYPE_ARRAY:
		return _parsed({}, "malformed conditions")
	var clauses: PackedStringArray = PackedStringArray()
	for item_v: Variant in value:
		if typeof(item_v) != TYPE_STRING:
			return _parsed({}, "condition clause must be a string")
		var item: String = str(item_v).strip_edges()
		if item.is_empty():
			return _parsed({}, "empty condition clause")
		clauses.append(item)
	return _parse_clause_list(clauses)


static func _parsed(conditions: Dictionary, error: String) -> Dictionary:
	return {"ok": error.is_empty(), "conditions": conditions, "error": error}


static func _split_clauses(text: String) -> PackedStringArray:
	var out: PackedStringArray = PackedStringArray()
	var normalized: String = text.strip_edges().replace(",", " ")
	for part: String in normalized.split(" ", false):
		var clause: String = part.strip_edges()
		if not clause.is_empty():
			out.append(clause)
	return out


static func _parse_clause_list(clauses: PackedStringArray) -> Dictionary:
	var conditions: Dictionary = {}
	var quests: Dictionary = {}
	var quest_progress: Dictionary = {}
	var shards_re: RegEx = RegEx.new()
	var act_re: RegEx = RegEx.new()
	var quest_re: RegEx = RegEx.new()
	var progress_re: RegEx = RegEx.new()
	shards_re.compile(_SHARDS_CLAUSE)
	act_re.compile(_ACT_CLAUSE)
	quest_re.compile(_QUEST_CLAUSE)
	progress_re.compile(_QUEST_PROGRESS_CLAUSE)
	for clause: String in clauses:
		var shards_found: RegExMatch = shards_re.search(clause)
		if shards_found != null:
			if conditions.has("shards_gte"):
				return _parsed({}, "duplicate shards clause")
			conditions["shards_gte"] = _ji(shards_found.get_string(1))
			continue
		var act_found: RegExMatch = act_re.search(clause)
		if act_found != null:
			if conditions.has("act"):
				return _parsed({}, "duplicate act clause")
			conditions["act"] = _ji(act_found.get_string(1))
			continue
		var progress_found: RegExMatch = progress_re.search(clause)
		if progress_found != null:
			var progress_id: String = progress_found.get_string(1)
			if quest_progress.has(progress_id):
				return _parsed({}, "duplicate quest progress clause")
			quest_progress[progress_id] = _ji(progress_found.get_string(2))
			continue
		var quest_found: RegExMatch = quest_re.search(clause)
		if quest_found != null:
			var quest_id: String = quest_found.get_string(1)
			var quest_state: String = quest_found.get_string(2)
			if quest_state not in QUEST_STATES:
				return _parsed({}, "unknown quest state %s" % quest_state)
			if quests.has(quest_id):
				return _parsed({}, "duplicate quest clause")
			quests[quest_id] = quest_state
			continue
		return _parsed({}, "unknown condition %s" % clause)
	if not quests.is_empty():
		conditions["quest_state"] = quests
	if not quest_progress.is_empty():
		conditions["quest_progress"] = quest_progress
	return _parsed(conditions, "")


static func context(run: RunState, shard_count: int = -1) -> Dictionary:
	var quests: Dictionary = {}
	var quest_progress: Dictionary = {}
	for id_v: Variant in run.quests:
		var rec_v: Variant = run.quests[id_v]
		if typeof(rec_v) != TYPE_DICTIONARY:
			continue
		var rec: Dictionary = rec_v
		var id: String = str(id_v)
		quests[id] = str(rec.get("state", "dormant"))
		quest_progress[id] = _ji(rec.get("progress", 0))
	return {
		"shards": shard_count if shard_count >= 0 else run.shards.size(),
		"act": run.act,
		"quests": quests,
		"quest_progress": quest_progress,
	}


## Current-run completions count: a fourth pane earned this journey opens L2
## before VigilState folds the receipt.
static func projected_shard_count(run: RunState, variant_id: StringName = &"") -> int:
	var seen: Dictionary = {}
	for shard_v: Variant in run.shards:
		seen[str(shard_v)] = true
	for completion_v: Variant in run.quest_completions:
		seen[str(completion_v)] = true
	if variant_id != &"ownShade3" or seen.has("ownShade"):
		return seen.size()
	var quest_v: Variant = run.quests.get("ownShade")
	if typeof(quest_v) != TYPE_DICTIONARY:
		return seen.size()
	var quest: Dictionary = quest_v
	if str(quest.get("state", "dormant")) not in ["armed", "revealed"]:
		return seen.size()
	var progress: int = _ji(quest.get("progress", 0))
	if progress + 1 >= 3:
		seen["ownShade"] = true
	return seen.size()


static func conditions_match(conditions_v: Variant, ctx: Dictionary) -> bool:
	if typeof(conditions_v) != TYPE_DICTIONARY:
		return false
	var conditions: Dictionary = conditions_v
	if conditions.has("shards_gte") and _ji(ctx.get("shards", 0)) < _ji(conditions["shards_gte"]):
		return false
	if conditions.has("act") and _ji(ctx.get("act", -1)) != _ji(conditions["act"]):
		return false
	if typeof(conditions.get("quest_state")) == TYPE_DICTIONARY:
		var wanted: Dictionary = conditions["quest_state"]
		var quests_v: Variant = ctx.get("quests", {})
		var quests: Dictionary = quests_v if typeof(quests_v) == TYPE_DICTIONARY else {}
		for id_v: Variant in wanted:
			if str(quests.get(str(id_v), "")) != str(wanted[id_v]):
				return false
	if typeof(conditions.get("quest_progress")) == TYPE_DICTIONARY:
		var wanted_progress: Dictionary = conditions["quest_progress"]
		var have_v: Variant = ctx.get("quest_progress", {})
		var have: Dictionary = have_v if typeof(have_v) == TYPE_DICTIONARY else {}
		for id_v: Variant in wanted_progress:
			if _ji(have.get(str(id_v), 0)) < _ji(wanted_progress[id_v]):
				return false
	return true


static func specificity(conditions_v: Variant) -> int:
	if typeof(conditions_v) != TYPE_DICTIONARY:
		return 0
	var conditions: Dictionary = conditions_v
	var n: int = 0
	if conditions.has("shards_gte"):
		n += 1
	if conditions.has("act"):
		n += 1
	var quests_v: Variant = conditions.get("quest_state")
	if typeof(quests_v) == TYPE_DICTIONARY:
		var quests: Dictionary = quests_v
		n += quests.size()
	var progress_v: Variant = conditions.get("quest_progress")
	if typeof(progress_v) == TYPE_DICTIONARY:
		var progress: Dictionary = progress_v
		n += progress.size()
	return n


static func has_slot(rows: Array, slot: String) -> bool:
	for row_v: Variant in rows:
		if typeof(row_v) == TYPE_DICTIONARY and str(row_v.get("slot", "")) == slot:
			return true
	return false


static func slot_open(rows: Array, slot: String, ctx: Dictionary) -> bool:
	for row_v: Variant in rows:
		if typeof(row_v) != TYPE_DICTIONARY:
			continue
		var row: Dictionary = row_v
		if str(row.get("slot", "")) == slot and conditions_match(row.get("conditions", {}), ctx):
			return true
	return false


static func row_by_id(rows: Array, id: String) -> Dictionary:
	for row_v: Variant in rows:
		if typeof(row_v) == TYPE_DICTIONARY and str(row_v.get("id", "")) == id:
			return row_v
	return {}


static func text(row: Dictionary, zh: bool) -> String:
	return str(row.get("zh" if zh else "en", ""))


static func ladder_of(row: Dictionary) -> int:
	var conditions_v: Variant = row.get("conditions", {})
	if typeof(conditions_v) != TYPE_DICTIONARY:
		return 0
	var n: int = _ji(conditions_v.get("shards_gte", 0))
	if n >= L3_SHARDS:
		return 3
	if n >= L2_SHARDS:
		return 2
	if n >= L1_SHARDS:
		return 1
	return 0


## `memory` is `{recent: Array, once: Array, last_id: String}`. `recent` is
## oldest-first runs of drawn ids. Empty dict = no line this slot this context.
static func select(
		rows: Array, slot: String, ctx: Dictionary, rng: Rng, memory: Dictionary
) -> Dictionary:
	var pool: Array[Dictionary] = _slot_rows(rows, slot)
	if pool.is_empty():
		return {}
	var once: Dictionary = _id_set(memory.get("once", []))
	var last_id: String = str(memory.get("last_id", ""))
	var recent_v: Variant = memory.get("recent", [])
	var recent: Array = recent_v if typeof(recent_v) == TYPE_ARRAY else []
	var matching: Array[Dictionary] = []
	for row: Dictionary in pool:
		if conditions_match(row.get("conditions", {}), ctx) \
				and not once.has(str(row.get("id", ""))):
			matching.append(row)
	var picked: Dictionary = _pick(matching, rng, recent, last_id, false)
	if not picked.is_empty():
		return picked
	picked = _pick(matching, rng, recent, last_id, true)
	if not picked.is_empty():
		return picked
	return _pick(matching, rng, [], "", true)


static func _slot_rows(rows: Array, slot: String) -> Array[Dictionary]:
	var out: Array[Dictionary] = []
	for row_v: Variant in rows:
		if typeof(row_v) != TYPE_DICTIONARY:
			continue
		var row: Dictionary = row_v
		if str(row.get("slot", "")) == slot and not str(row.get("id", "")).is_empty():
			out.append(row)
	return out


static func _id_set(value: Variant) -> Dictionary:
	var out: Dictionary = {}
	if typeof(value) != TYPE_ARRAY:
		return out
	for id_v: Variant in value:
		var id: String = str(id_v)
		if not id.is_empty():
			out[id] = true
	return out


static func _used_in(recent: Array, id: String, cooldown_runs: int) -> bool:
	if cooldown_runs <= 0 or id.is_empty():
		return false
	var from: int = maxi(0, recent.size() - cooldown_runs)
	for i: int in range(from, recent.size()):
		var run_v: Variant = recent[i]
		if typeof(run_v) != TYPE_ARRAY:
			continue
		for drawn_v: Variant in run_v:
			if str(drawn_v) == id:
				return true
	return false


static func _pick(
		matching: Array[Dictionary], rng: Rng, recent: Array, last_id: String,
		recycle: bool
) -> Dictionary:
	var eligible: Array[Dictionary] = []
	var best_spec: int = -1
	var best_pri: int = -2147483648
	for row: Dictionary in matching:
		var id: String = str(row.get("id", ""))
		if not recycle and _used_in(recent, id, _ji(row.get("cooldown_runs", DEFAULT_COOLDOWN_RUNS))):
			continue
		if recycle and id == last_id:
			continue
		var spec: int = specificity(row.get("conditions", {}))
		var pri: int = _ji(row.get("priority", 0))
		if spec > best_spec or (spec == best_spec and pri > best_pri):
			best_spec = spec
			best_pri = pri
			eligible = [row]
		elif spec == best_spec and pri == best_pri:
			eligible.append(row)
	if eligible.is_empty():
		return {}
	if eligible.size() == 1 or rng == null:
		return eligible[0]
	var total: int = 0
	for row: Dictionary in eligible:
		total += maxi(1, _ji(row.get("weight", 1)))
	var ticket: int = rng.pick_index(total)
	var cursor: int = 0
	for row: Dictionary in eligible:
		cursor += maxi(1, _ji(row.get("weight", 1)))
		if ticket < cursor:
			return row
	return eligible[0]


## Append exactly one run bucket, including an empty bucket when this run
## drew nothing. Cooldown counts terminal runs, not loss-draws.
static func remember(recent: Array, ids: Array) -> Array:
	var bucket: Array = []
	for id_v: Variant in ids:
		var id: String = str(id_v)
		if not id.is_empty():
			bucket.append(id)
	var next: Array = recent.duplicate()
	next.append(bucket)
	while next.size() > RECENT_CAP:
		next.pop_front()
	return next
