extends SceneTree
const CausalProbe: GDScript=preload("res://causal_probe.gd")
const HealthAccounting: GDScript=preload("res://health_accounting.gd")
const Policy: GDScript=preload("res://lab_policy.gd")
const RandomShop: GDScript=preload("res://random_shop_control.gd")
var policy: RefCounted
var cfg: Dictionary={}
var played: Dictionary={}
var offered: Dictionary={}
var picked: Dictionary={}
var fights: Array=[]
var action_diagnostics: Array=[]
var mechanism: Dictionary={}
var fight_mechanism: Dictionary={}
var causal_samples: Array=[]
var probe_seen: Dictionary={}
var probe_failed: bool=false
func observed_apply(g: GlassvowGame,command: Dictionary,source: String) -> Array[Dictionary]:
 var captured: Dictionary={}
 if cfg.get("causal_probe",false) and str(command.get("t",""))=="playCard":
  var kind: String=CausalProbe.role(g,command)
  if not kind.is_empty():
   var value: int=CausalProbe.mediator(g,command,kind)
   measure("probe_eligible:"+kind)
   var key: String=kind+(":positive" if value>0 else ":zero")
   if not probe_seen.has(key):
    captured=CausalProbe.sample(g,command)
    if not captured.get("ok",false):
     probe_failed=true;push_error("LAB_CAUSAL_CAPTURE "+str(captured.get("reason")));return []
    captured.record["fight"]=fights.size()
    causal_samples.append(captured.record);probe_seen[key]=true
 var before: Dictionary=HealthAccounting.snapshot(g.cb)
 var events: Array[Dictionary]=g.apply(command)
 if not captured.is_empty() and not CausalProbe.verify_factual(g,events,captured):
  probe_failed=true;push_error("LAB_CAUSAL_FACTUAL_MISMATCH")
 var result: Dictionary=HealthAccounting.fold(before,events,HealthAccounting.snapshot(g.cb))
 if not result.ok:push_error("LAB_HEALTH_ACCOUNT "+str(result.reason));return events
 measure("actual_hp_removed:"+source,int(result.removed))
 measure("actual_hp_removed_total",int(result.removed))
 measure("poison_hp_removed",int(result.poison_removed))
 measure("enemy_healing",int(result.healed))
 return events
func measure(key: String,n: int=1) -> void:
 bump(mechanism,key,n);bump(fight_mechanism,key,n)
func ji(v: Variant) -> int:return int(float(str(v)))
func bump(d: Dictionary,k: String,n: int=1) -> void:d[k]=ji(d.get(k,0))+n
func _initialize() -> void:
 var a: PackedStringArray=OS.get_cmdline_user_args()
 if a.size()!=2:printerr("LAB_BAD_ARGS");quit(2);return
 cfg=JSON.parse_string(FileAccess.get_file_as_string(a[0]))
 policy=Policy.new();policy.route=str(cfg.get("route","balanced"));policy.random_build=cfg.get("random_build",false);policy.random_play=cfg.get("random_play",false);policy.params=cfg.get("params",{})
 var path: String=str(cfg.get("content_path","res://content/full-content.json"));var db: ContentDB=ContentDB.load_from(path,true)
 if db==null:printerr("LAB_BAD_CONTENT");quit(2);return
 var out: FileAccess=FileAccess.open(a[1],FileAccess.WRITE)
 if out==null:printerr("LAB_BAD_OUTPUT");quit(2);return
 out.store_line(JSON.stringify({"kind":"manifest","engine":Engine.get_version_info(),"content_sha256":FileAccess.get_sha256(path),"driver_sha256":FileAccess.get_sha256("res://lab_runner.gd"),"policy_sha256":FileAccess.get_sha256("res://lab_policy.gd"),"config":cfg,"qualification":false}))
 var start: int=Time.get_ticks_msec()
 for j: int in range(ji(cfg.get("runs",1))):
  out.store_line(JSON.stringify(simulate(db,ji(cfg.get("seed0",1000000))+j)))
  if j%10==0:out.flush()
 out.flush();print(JSON.stringify({"kind":"done","ms":Time.get_ticks_msec()-start,"runs":cfg.get("runs",1)}));quit(0)
func simulate(db: ContentDB,seed: int) -> Dictionary:
 played={};offered={};picked={};fights=[];action_diagnostics=[];mechanism={}
 causal_samples=[];probe_failed=false
 var unlocks: Array=["aspect2"]
 if cfg.get("all_deeds",false):
  for deed: Dictionary in db.deeds.values():
   for u: Variant in deed.get("unlocks",[]):
    if not unlocks.has(u):unlocks.append(u)
 var profile: Dictionary={"aspect":ji(cfg.get("aspect",0)),"vow":ji(cfg.get("vow",0)),"reveals":db.reveal_ids.duplicate(),"unlocks":unlocks,"quests":{},"shards":[],"lamplighter":false}
 var run: RunState=RunState.new_run(db,seed,"lab-%d"%seed,profile);var g: GlassvowGame=GlassvowGame.new(db,run)
 if cfg.has("fixed_deck"):
  run.player.deck.clear()
  for spec: Variant in cfg["fixed_deck"]:
   var id: String=str(spec);var up: bool=id.ends_with("+")
   if up:id=id.left(-1)
   run.player.deck.append(CardInst.new(run.next_uid(),StringName(id),up))
 for rid: Variant in cfg.get("fixed_relics",[]):g.rewards.gain_relic(run,str(rid))
 if cfg.has("encounter"):
  run.act=ji(cfg.get("act",0))
  while run.omens.size()<=run.act:run.omens.append(null)
  return finish(g,seed,fight(g,cfg["encounter"],str(cfg.get("combat_kind","normal"))))
 for act: int in range(3):
  var map: WorldMap=WorldMap.benchmark(run)
  while not map.is_finished():
   var available: Array[int]=map.reachable();var idx: int=available[0]
   if policy.random_build:idx=available[run.rng.pick_index(available.size())]
   else:
    var high: float=-INF;var low: bool=run.player.hp*100<run.player.max_hp*ji(policy.params.get("route_low",55))
    for k: int in available:
     var nd: MapNode=map.nodes[k];var sc: float=float({"boss":100,"treasure":90,"rest":95 if low else 50,"shop":80 if run.player.gold>=140 else 30,"event":65,"elite":20 if low else 60,"monster":40}.get(nd.type,0))
     if sc>high:high=sc;idx=k
   if not map.enter(idx):return finish(g,seed,"error")
   var node: MapNode=map.current();run.node_id=node.id;run.waystones_lit=node.row+1
   if node.unlit:
    var gold: int=node.bounty*(2 if run.has_relic("thiefOfWicks") else 1)
    run.player.gold+=gold;bump(run.stats,"goldEarned",gold);bump(run.stats,"unlitVisited")
   if node.is_combat():
    var enemies: Array=node.enemies.duplicate()
    if enemies.is_empty():enemies=g.rewards.roll_encounter(run,node.type,node.row,node)
    if enemies.is_empty():return finish(g,seed,"error")
    var result: String=fight(g,enemies,node.combat_kind())
    if result!="win":return finish(g,seed,result)
    if node.type=="boss" and run.act==2:return finish(g,seed,"win")
    claim(g,g.gen_combat_rewards(node.combat_kind(),g.cb.affix))
   else:safe(g,node)
   map.clear_current()
   if node.type=="boss":
    var rid: String=policy.choose_relic(g.rewards.roll_boss_relics(run),g)
    if not rid.is_empty():g.rewards.gain_relic(run,rid)
    run.boss_relic_act=run.act;run.start_next_act(db);break
 return finish(g,seed,"error")
func finish(g: GlassvowGame,seed: int,result: String) -> Dictionary:
 var deck: Array=[]
 for c: CardInst in g.run.player.deck:deck.append(String(c.id)+("+" if c.up else ""))
 return {"kind":"row","seed":seed,"aspect":g.run.aspect,"vow":g.run.vow,"route":policy.route,"random_build":policy.random_build,"random_play":policy.random_play,"result":result,"act":g.run.act+1,"hp":g.run.player.hp,"max_hp":g.run.player.max_hp,"deck":deck,"relics":g.run.player.relics,"stats":g.run.stats,"played":played,"offered":offered,"picked":picked,"fights":fights,"action_diagnostics":action_diagnostics,"mechanism":mechanism,"causal_samples":causal_samples}
func fight(g: GlassvowGame,enemies: Array,kind: String) -> String:
 fight_mechanism={};probe_seen={}
 g.apply({"t":"startCombat","enemies":enemies,"kind":kind})
 var sh: int=ji(g.run.stats.get("shatters",0));var before: Dictionary=played.duplicate();var maxstr: int=0;var maxpoison: int=0;var maxembers: int=g.cb.embers;var bonus: int=0
 while not g.cb.over:
  potions(g)
  for guard: int in range(100):
   if g.cb.over:break
   var action: Dictionary=policy.choose_action(g)
   if action.is_empty():break
   var cast_id: String="";var cast_str: int=0;var cast_bonus: int=0;var cast_hand: int=0;var cast_embers: int=0;var cast_poison: int=0;var cast_multihit: bool=false
   if str(action["t"])=="playCard":
    for c: CardInst in g.cb.hand:
     if c.uid==action["uid"]:
      cast_id=String(c.id);cast_bonus=c.bonus;bump(played,cast_id)
      var cd: Dictionary=g.rules.card_data(c)
      for fx: Dictionary in cd.get("effects",[]):
       if str(fx.get("kind",""))=="dmg" and ji(fx.get("times",1))>1:cast_multihit=true
      break
    cast_str=ji(g.cb.player.statuses.get("str",0));cast_hand=maxi(0,g.cb.hand.size()-1);cast_embers=g.cb.embers
    var target_v: Variant=action.get("target")
    if target_v!=null:cast_poison=ji(g.cb.enemies[ji(target_v)].statuses.get("poison",0))
   var events: Array[Dictionary]=observed_apply(g,action,cast_id if cast_id!="" else str(action["t"]))
   if probe_failed:return "error"
   if cast_id!="" and g.last_ret==true:
    var hits: int=0;var damage: int=0;var shatters: int=0
    for ev: Dictionary in events:
     if ev.get("t")==EventTypes.HIT_ENEMY:hits+=1;damage+=maxi(0,ji(ev.get("amount",0)))
     if ev.get("t")==EventTypes.SHATTER:shatters+=1
    measure("card_damage:"+cast_id,damage);measure("card_hits:"+cast_id,hits)
    if shatters>0:measure("shatter_events",shatters)
    if cast_multihit and hits>=2 and cast_str>0:measure("multi_hit_with_str_casts");measure("multi_hit_str_sum",cast_str)
    if cast_id=="momentum":
     measure("momentum_casts");measure("momentum_bonus_sum",cast_bonus)
     if cast_bonus>0:measure("grown_momentum_casts")
    if cast_id=="phantomBlades":measure("phantom_casts");measure("phantom_hand_sum",cast_hand)
    if cast_id=="novaflare":measure("nova_casts");measure("nova_embers_sum",cast_embers)
    if cast_id=="catalyst":
     measure("catalyst_casts");measure("catalyst_poison_sum",cast_poison)
     if cast_poison>0:measure("catalyst_nonzero_casts")
   if action["t"]=="playCard" and g.last_ret!=true:
    action_diagnostics.append({"reason":"illegal_action","action":action,"turn":g.cb.turn});printerr("LAB_ILLEGAL_ACTION");return "error"
   maxstr=maxi(maxstr,ji(g.cb.player.statuses.get("str",0)));maxembers=maxi(maxembers,g.cb.embers)
   for e: EnemyCombatant in g.cb.enemies:maxpoison=maxi(maxpoison,ji(e.statuses.get("poison",0)))
   for c: CardInst in g.cb.discard:bonus=maxi(bonus,c.bonus)
   if guard==99:
    action_diagnostics.append({"reason":"action_ceiling","turn":g.cb.turn,"energy":g.cb.player.energy,"hand_size":g.cb.hand.size()});printerr("LAB_ACTION_CEILING");return "error"
  if g.cb.over:break
  if g.cb.turn>=30:
   g.run.player.hp=maxi(0,g.cb.player.hp);break
  observed_apply(g,{"t":"endTurn"},"endTurn")
 var result: String=g.cb.result if g.cb.over else "stall";var delta: Dictionary={}
 for key: Variant in played:
  var n: int=ji(played[key])-ji(before.get(key,0))
  if n>0:delta[key]=n
 fights.append({"act":g.run.act+1,"kind":kind,"enemies":enemies,"result":result,"turns":g.cb.turn,"hp_lost":g.cb.hp_lost,"shatters":ji(g.run.stats.get("shatters",0))-sh,"max_str":maxstr,"max_poison":maxpoison,"max_embers":maxembers,"momentum_bonus":bonus,"played":delta,"mechanism":fight_mechanism})
 return result
func potions(g: GlassvowGame) -> void:
 for i: int in range(g.run.player.potions.size()):
  if g.cb.over:return
  var id: String=g.run.player.potions[i];var use: bool=id=="healing" and g.cb.player.max_hp-g.cb.player.hp>=20
  use=use or id=="block" and policy.incoming(g)-g.cb.player.block>=g.cb.player.hp
  use=use or g.cb.kind!=&"normal" and id in ["strength","swift","fire","venom","energy"]
  if not use:continue
  var target: Variant=null
  if id in ["fire","venom"]:
   var living: Array[EnemyCombatant]=g.cb.living_enemies()
   if living.is_empty():continue
   target=living[0].idx
   for e: EnemyCombatant in living:
    if (id=="venom" and e.hp>g.cb.enemies[target].hp) or (id=="fire" and e.hp<g.cb.enemies[target].hp):target=e.idx
  observed_apply(g,{"t":"usePotion","slot":i,"target":target},"potion:"+id)
func add_card(g: GlassvowGame,id: String,up: bool=false) -> void:
 if id.is_empty():return
 g.run.player.deck.append(CardInst.new(g.run.next_uid(),StringName(id),up));bump(picked,id)
func claim(g: GlassvowGame,r: Dictionary) -> void:
 var gold: int=ji(r.get("gold",0));g.run.player.gold+=gold;bump(g.run.stats,"goldEarned",gold)
 for id: Variant in r.get("cards",[]):bump(offered,str(id))
 add_card(g,policy.choose_card(r.get("cards",[]),g,true))
 if r.get("potion")!=null:
  var i: int=g.run.player.potions.find("")
  if i>=0:g.run.player.potions[i]=str(r["potion"])
 for key: String in ["relic","relic2"]:
  if r.get(key)!=null:g.rewards.gain_relic(g.run,str(r[key]))
func upgrade(g: GlassvowGame) -> void:
 var c: CardInst=policy.best_card(g,false,true)
 if c!=null:c.up=true
func safe(g: GlassvowGame,node: MapNode) -> void:
 if node.type=="rest":
  if g.run.player.hp*100<g.run.player.max_hp*ji(policy.params.get("rest",70)):
   g.run.player.hp=mini(g.run.player.max_hp,g.run.player.hp+int(roundf(g.run.player.max_hp*g.rewards.rest_heal_fraction(g.run))))
  else:upgrade(g)
 elif node.type=="treasure":g.rewards.claim_treasure(g.run)
 elif node.type=="shop":shop(g)
 elif node.type=="event":event(g)
func event(g: GlassvowGame) -> void:
 var eid: String=g.rewards.roll_event(g.run)
 if not g.content.events.has(eid):return
 var choices: Array=g.content.events[eid].get("choices",[]);var selected: Dictionary={};var top: float=-INF
 for c: Dictionary in choices:
  if g.run.player.gold<ji(c.get("needGold",0)):continue
  var v: float=op_score(g,c.get("ops",[]))
  if v>top:top=v;selected=c
 if selected.is_empty():return
 var pending: Dictionary=g.rewards.apply_event_ops(g.run,selected.get("ops",[]))
 match str(pending.get("kind","")):
  "card":
   for id: Variant in pending.get("cards",[]):bump(offered,str(id))
   add_card(g,policy.choose_card(pending.get("cards",[]),g,false))
  "upgrade":upgrade(g)
  "remove":
   var c: CardInst=policy.best_card(g,true)
   if c!=null:g.run.player.deck.erase(c)
  "duplicate":
   var c: CardInst=policy.best_card(g)
   if c!=null:add_card(g,String(c.id),c.up)
func op_score(g: GlassvowGame,ops: Array) -> float:
 var value: float=0
 for op: Dictionary in ops:
  if op.has("roll"):
   for b: Dictionary in op["roll"]:value+=float(b.get("p",0))*op_score(g,b.get("ops",[]))
  elif op.has("gold"):value+=ji(op["gold"])*0.12
  elif op.has("hp"):value+=minf(ji(op["hp"]),g.run.player.max_hp-g.run.player.hp)*0.8
  elif op.has("heal"):value+=minf(g.run.player.max_hp*float(op["heal"]),g.run.player.max_hp-g.run.player.hp)*0.8
  elif op.has("maxHp"):value+=ji(op["maxHp"])*1.2
  elif op.has("addCard"):value+=policy.draft(g,g.content.cards.get(str(op["addCard"]),{}),str(op["addCard"]))
  elif op.has("addRelic"):value+=20 if str(op["addRelic"])=="random" else policy.relic_score(str(op["addRelic"]),g)
  elif op.has("potion"):value+=8 if g.run.player.potions.has("") else 0
  elif op.get("pickRemove",false):value+=16
  elif op.get("pickUpgrade",false):value+=10
  elif op.get("pickDuplicate",false):value+=12
  elif op.has("pickCard"):value+=14
 return value
func shop(g: GlassvowGame) -> void:
 var s: Dictionary=g.rewards.gen_shop(g.run);var used: Dictionary={}
 for row: Dictionary in s.get("cards",[]):bump(offered,str(row["id"]))
 if policy.random_build:
  for op: Dictionary in RandomShop.plan(s,g.run):
   g.run.player.gold-=ji(op["price"])
   match str(op["category"]):
    "cards":add_card(g,str(op["id"]))
    "relics":g.rewards.gain_relic(g.run,str(op["id"]))
    "potions":g.run.player.potions[g.run.player.potions.find("")]=str(op["id"])
    "remove":
     for cc: CardInst in g.run.player.deck:
      if cc.uid==op["uid"]:g.run.player.deck.erase(cc);break
  return
 for guard: int in range(8):
  var opts: Array[Dictionary]=[];var vals: Array[float]=[]
  for cat: String in ["cards","relics","potions"]:
   for j: int in range(s.get(cat,[]).size()):
    var row: Dictionary=s[cat][j];var key: String=cat+str(j);var id: String=str(row["id"]);var price: int=ji(row["price"])
    if used.has(key) or price>g.run.player.gold:continue
    if cat=="potions" and not g.run.player.potions.has(""):continue
    var v: float=policy.draft(g,g.content.cards[id],id) if cat=="cards" else policy.relic_score(id,g) if cat=="relics" else 9.0
    opts.append({"cat":cat,"id":id,"price":price,"key":key});vals.append(v/maxf(1,price))
  var c: CardInst=policy.best_card(g,true);var remove: int=ji(s["removeCost"])
  if not used.has("remove") and c!=null and remove<=g.run.player.gold:
   opts.append({"cat":"remove","id":"","price":remove,"key":"remove","uid":c.uid});vals.append((22.0-policy.draft(g,g.content.cards[String(c.id)],String(c.id),false))/maxi(1,remove))
  var best: int=-1
  var top: float=float(policy.params.get("shop_ratio",0.13))
  for j: int in range(vals.size()):
   if vals[j]>top:top=vals[j];best=j
  if best<0:return
  var op: Dictionary=opts[best];g.run.player.gold-=ji(op["price"]);used[op["key"]]=true
  match str(op["cat"]):
   "cards":add_card(g,str(op["id"]))
   "relics":g.rewards.gain_relic(g.run,str(op["id"]))
   "potions":g.run.player.potions[g.run.player.potions.find("")]=str(op["id"])
   "remove":
    for cc: CardInst in g.run.player.deck:
     if cc.uid==op["uid"]:g.run.player.deck.erase(cc);break
