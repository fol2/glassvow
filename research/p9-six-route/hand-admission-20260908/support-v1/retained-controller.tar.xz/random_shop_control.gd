extends RefCounted
## Research extraction of BalancePilot._random_shop at main 2ed6cdb.
## Same category order, one equal stop option and random removal target.
## No bans in this study. Plans purchases before applying them, as the source does.
static func plan(stock: Dictionary,run: RunState) -> Array[Dictionary]:
 var gold: int=run.player.gold
 var potion_free: int=run.player.potions.count("")
 var taken: Dictionary={}
 var removed: bool=false
 var bought: Array[Dictionary]=[]
 var remove_cost: int=int(float(str(stock.get("removeCost",75))))
 for _guard: int in range(8):
  var options: Array[Dictionary]=[]
  for category: String in ["relics","cards","potions"]:
   for row_v: Variant in stock.get(category,[]):
    var row: Dictionary=row_v
    var key: String="%s:%s" % [category,row["id"]]
    if not taken.has(key) and int(float(str(row["price"])))<=gold and (category!="potions" or potion_free>0):
     options.append({"category":category,"id":str(row["id"]),"price":row["price"],"key":key})
  if not removed and remove_cost<=gold and not run.player.deck.is_empty():
   options.append({"category":"remove","price":remove_cost})
  var pick: int=run.rng.pick_index(options.size()+1)
  if pick==options.size():break
  var chosen: Dictionary=options[pick]
  if str(chosen["category"])=="remove":
   var card: CardInst=run.player.deck[run.rng.pick_index(run.player.deck.size())]
   chosen.merge({"id":String(card.id),"uid":card.uid})
   removed=true
  else:
   taken[str(chosen["key"])]=true
   if str(chosen["category"])=="potions":potion_free-=1
  bought.append(chosen)
  gold-=int(float(str(chosen["price"])))
 return bought
